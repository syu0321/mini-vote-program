const app = getApp()
Page({
  data:{		//此处定义本页面中的全局变量
    result: '',		
    userID: '',
    userpwd: ''
  },
  inputID: function(e){	// 用于获取输入的账号
    this.setData({
      userID: e.detail.value	//将获取到的账号赋值给username变量
    })
  },
  inputPwd: function (e) {		// 用于获取输入的密码
    this.setData({
      userpwd: e.detail.value	//将获取到的账号赋值给passwd变量
    })
  },
  //传递数值

  log: function(e){		//与服务器进行交互
    wx.request({
      url: 'https://syu.fit/api/login/',	//获取服务器地址，此处为本地地址
      header:{
        "content-type": "application/x-www-form-urlencoded"		//使用POST方法要带上这个header
      },
      method: "POST",
      data: {		//向服务器发送的信息
        userID: this.data.userID,
        userpwd: this.data.userpwd
      },
      //把身份证号放到全局变量
      success: res => {
        this.setData({
          result: res.data	//服务器返回的结果
        })
        if(res.data.data.userroot == 0)
          {
            wx.showToast({
              title: '消息待审核！',
            })
          }
        if(res.data.status == false)
          {
            wx.showToast({
              title: '账号或者密码错误！',
            })
          }
        if (res.data.status == true) {
          wx.reLaunch({
            url: '../home/home',
          })
          app.globalData.userID = res.data.data.userID
        }
      }
    })
  },
  //注册用户信息
  info:function(){
    wx.reLaunch({
      url:'../info/info',
    })
  }
})
