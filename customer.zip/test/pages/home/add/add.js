var uploadImage = require('../../js/uploadImg/uploadImg.js');
var app = getApp()
//获取当前时间
var utils = (function () {
  var time = new Date()
  return {
    year: time.getFullYear(),
    month: time.getMonth() + 1,
    date: time.getDate(),
    hours: time.getHours(),
    minutes: time.getMinutes()
  }
})()
Page({
  data: {
    title: '', //投票标题
    description: '',//补充描述
    tempUnique: 2,//每添加一次选项，tempUnique+1,防止删除选项时造成重复
    optionData: [
      { unique: 0, content: '', number: 0, joiner: []},
      { unique: 1, content: '', number: 0, joiner: []}
    ],
    date: '', //投票截止日期
    time: '', //投票截止时间
    //radio: 0,   //单选还是多选
    userId: null,
    imageList:[],
    photo:[],
  },
  //页面监听
  onLoad: function (options) {
    var that = this;
    that.setData({
      date: utils.year + '-' + ('0' + utils.month).substr(-2) + '-' + ('0' + utils.date).substr(-2),
      time: ('0' + utils.hours).substr(-2) + ':' + ('0' + utils.minutes).substr(-2),
      userId: options.userId
    })
  },
  //标题
  bindTitleInput: function (e) {
    var that = this;
    that.setData({
      title: e.detail.value,
    });
  },
  bindDescribeInput: function (e) {
    var that = this;
    that.setData({
      description: e.detail.value,
    });
  },
  //添加选项
  addOption: function (e) {
    var that = this;
    var tempUnique0 = that.data.tempUnique;
    var optionData0 = that.data.optionData;
    optionData0.push({ unique: tempUnique0, content: '', number: 0, percent: 0, joiner:[]})
    tempUnique0++;
    that.setData({
      tempUnique: tempUnique0,
      optionData: optionData0
    })
  },
  //删除选项
  reduceOption: function (e) {
    var that = this;
    var optionData0 = that.data.optionData;
    for (var i = 0; i < optionData0.length; i++) {
      if (optionData0[i].unique == e.target.dataset.unique) {
        optionData0.splice(i, 1)
        that.setData({
          optionData: optionData0
        })
        return false;
      }
    }
  },
  //选项内容
  bindBlur: function (e) {
    var that = this;
    var optionData0 = that.data.optionData;
    for (var i = 0; i < optionData0.length; i++) {
      if (optionData0[i].unique == e.target.dataset.unique) {
        optionData0[i].content = e.detail.value;
        that.setData({
          optionData: optionData0
        })
        return false;
      }
    }
  },
  //设置时间
  bindDateChange: function (e) {
    var that = this;
    that.setData({
      date: e.detail.value,
    })
  },
  bindTimeChange: function (e) {
    var that = this;
    that.setData({
      time: e.detail.value,
    })
  },
  choose: function () {
    var that = this
    wx.chooseImage({
      count: 9, // 默认最多一次选择3张图
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        that.setData({
          imageList:that.data.imageList.concat(res.tempFilePaths)
        })
        for (var i = 0; i < that.data.imageList.length; i++) {
          //显示消息提示框
          wx.showLoading({
            title: '上传中' + (i + 1) + '/' + that.data.imageList.length,
            mask: true
          })
          //上传图片
          //你的域名下的/images/当前年月日文件下的/图片.png
          //图片路径可自行修改【(这二个参数就是你oss地址目录的下一个路径目录，比如:https://xxx.com/images/xxx.png)】
    
          uploadImage(that.data.imageList[i],'images/',
            function (result) {
              console.log("======上传成功图片地址为：", result);
              photo:that.data.photo.push(result)
              //这个result就是返给你上传到oss上的地址链接
              wx.hideLoading();
              wx.showToast({
                title:'上传成功'
              })
            }, function (result) {
              console.log("======上传失败======", result);
              wx.hideLoading()
              wx.showToast({
                title:'上传失败'
              })
            }
          )
        }
      }
    })
  },
  deleteImg: function (e) {
    var that = this;
    var imgs = that.data.imageList;
    var index = e.currentTarget.dataset.index;
    imgs.splice(index, 1);
    that.data.photo.splice(index, 1);
     this.setData({
      imageList:imgs,
       photo: that.data.photo
     });
  },
  //提交
  ok: function () {
    var that = this;
    if (that.data.title == '') {
      wx.showModal({
        title: '警告!',
        content: '投票标题必需填写',
        success: function (res) {
        }
      })
    } else {
      wx.request({
        url:'https://syu.fit/api/vote/',
        header:{
          "content-type": "application/x-www-form-urlencoded"		//使用POST方法要带上这个
        },
        method: "POST",
        data: {
          title: that.data.title,
          description:that.data.description,
          optionData: JSON.stringify(that.data.optionData),//json转换为字符串
          date: that.data.date, //活动日期
          time: that.data.time, //活动时间
          userId:that.data.userId,
          photo:that.data.photo,
        },
        success: res => {
          if (res.statusCode == 200) {
            wx.navigateBack({})
            this.setData({
              result: res.data	//服务器返回的结果
            })
          }
        }
      });
    }
  }
})