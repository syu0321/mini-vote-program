// pages/voteDetail/voteDetail.js
var app = getApp();
app.globalData.userID
Page({

  /**
   * 页面的初始数据
   */
  data: {
    detailList:[],
    taskData:[],
    okWord: '确 认 投 票'
  },
//监听
  onLoad: function (options) {
    var voteID = options.voteID
    //console.log(voteID)
    wx.request({
      url: 'https://syu.fit/api/detail/' + voteID +"/",
      method:'GET',
      dataType:"json",
      responseType:'text',
      success:(res)=>{
        var data = JSON.parse(res.data.optionData)//没问题
        var uniqueClickState = {};
        for(let i=0;i<data.length;i++)
        {
          let value = data[i].unique
          uniqueClickState[value] = false;
        }
        for (var i = 0; i < data.length; i++) {
            for (var j = 0; j < data[i].joiner.length; j++) {
              if (data[i].joiner[j] == app.globalData.userID) {
                this.setData({
                  okWord: '已投票',
                })
              }
            }
          }
        this.setData({
          description : res.data.description,
          detailList: data,
          taskData:res.data,
          photo : res.data.photo.split(","),
          uniqueClickState:uniqueClickState
        })
      }
    })
  },

  //投票选择
  voteOne: function (e) { //配置单选/多选的选择状态
    var that = this;
    var optionData = that.data.detailList
    var opendate = that.data.taskData.date;
   // var date = that.data.taskData.date;
    //var time = that.data.taskData.time;
    console.log(that.data.okWord)
    if (that.data.okWord!='已投票' && that.data.taskData.radio == 0) { //未投票，且是单选
      var uniqueClickState = {};
      for (let i = 0; i < that.data.detailList.length; i++) {
        let value = optionData[i].unique
        uniqueClickState[value] = false;
      }
      uniqueClickState[e.currentTarget.dataset.unique] = !uniqueClickState[e.currentTarget.dataset.unique]
      that.setData({  //保存当前状态
        uniqueClickState: uniqueClickState,
      })
    }else {
      wx.showModal({
        title: '提示',
        content: '您已投过票啦！',
      })
    }
  },
  //投票
  ok:function()
  {
    var that = this;
    var hasSelected = false;  //初始状态用户未选择选项
    var item = -1;
    var id =that.data.taskData.id;
    for (var i =0;i<that.data.detailList.length; i++)
    {
      //选择选项
      console.log(that.data.uniqueClickState[that.data.detailList[i].unique])
      if(that.data.uniqueClickState[that.data.detailList[i].unique]){
        hasSelected = true;
        break;
      }
    }
    if (!hasSelected) { //判断当前用户是否选择了选项
      wx.showToast({
        title: '请勾选您的选项！',
      })
    } else {
      wx.showModal({
        title: '提示',
        content: '投票成功！',
      })
    }
    wx.request({  //再次请求投票任务的详情数据，防止其他用户更新了数据库
      url: 'https://syu.fit/api/olddata/'+ id +"/",
      method:'GET',
      data: {
        id: that.data.taskData.id,
      },
      dataType: 'json',
      success: function (res) {
        /*获取最新的数据库数据，并将点击选项后的数据在本地更新*/
        var data = JSON.parse(res.data.optionData)//没问题
        //console.log(data)
        var totalNumber = 0;
        for (var i = 0; i < data.length; i++) { //计算总投票数
          totalNumber = totalNumber + data[i].number;
        }
        for (var j = 0; j < data.length; j++) {
          if (that.data.uniqueClickState[data[j].unique]) {
            that.setData({
          okWord: '已投票', 
        });
            data[j].number = data[j].number + 1;
            totalNumber = totalNumber + 1;
            data[j].joiner.push(app.globalData.userID);// 在当前选项中压入openid和图片
          }
        }
        that.submit(data)
        /*将本地的数据提交到数据库*/
      }
    });
  },
  submit:function(data)
  {
    var that = this
    wx.request({  //将投票后的optionData0更新保存到数据库，并且单独保存openid为user表示该用户已
      url: 'https://syu.fit/api/save/',
      header:{
        "content-type": "application/x-www-form-urlencoded"		//使用POST方法要带上这个
      },
      method: "POST",
      data: {
        id: that.data.taskData.id,
        optionData: JSON.stringify(data),
        openid:app.globalData.userID
      },
      dataType: 'json',
      success: function (res) {
        that.setData({
          optionData: data,
        })
        /*that.setData({
          okWord: '已投票', 
        });*/
      }
    });
  },
  del:function()
  {
    var that = this
    wx.request({  //再次请求投票任务的详情数据，防止其他用户更新了数据库
      url: 'https://syu.fit/api/del/',
      header:{
        "content-type": "application/x-www-form-urlencoded"		//使用POST方法要带上这个
      },
      method: "POST",
      data: {
        id: that.data.taskData.id,
        userID : app.globalData.userID,
      },
      dataType: 'json',
      success: function (res) {
        that.setData({
          result: res.data	//服务器返回的结果
        })
        if(res.data.data.userroot == 1)
        {
          wx.showToast({
            title: '您没有权限！',
          })
        }
        else if(res.data.status = true)
          {
            wx.showToast({
              title: '删除成功',
            })
            wx.reLaunch({
              url: '../home/home',
            })
          }
      }
    });
  },
  //展示票数
  show:function(){
    const CHARTS = require('../chart/chart.js');
    var that = this;
    var id =that.data.taskData.id;
    wx.request({  //再次请求投票任务的详情数据，防止其他用户更新了数据库
      url: 'https://syu.fit/api/olddata/'+ id +"/",
      method:'GET',
      data: {
        id: that.data.taskData.id,
      },
      dataType: 'json',
      success: function (res) {
        /*获取最新的数据库数据，并将点击选项后的数据在本地更新*/
        var data = JSON.parse(res.data.optionData)//没问题
        var s = []
        for (var i = 0; i < data.length; i++) { 
          s.push({data:data[i].number,name:data[i].content})
        }
        let pie = {
          canvasId: 'pieGraph', // canvas-id
          type: 'pie', // 图表类型，可选值为pie, line, column, area, ring
          series: s,
          width: 310, // 宽度，单位为px
          height: 200, // 高度，单位为px
          legend: true, // 是否显示图表下方各类别的标识
          dataLabel: true, // 是否在图表中显示数据内容值
          extra: {
            pie: {
              offsetAngle: -90
            }
          }
        };
        new CHARTS(pie);    
      }
    });
  },
   //预览图片
 photo_view: function(e){
   var that = this
   var url = e.currentTarget.dataset.url;
   wx.previewImage({
    current: url, // 当前显示图片的http链接
    //urls: that.data.previewImgArr.split(",") // 需要预览的图片http链接列表
    urls:that.data.photo
  })
  },

  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})