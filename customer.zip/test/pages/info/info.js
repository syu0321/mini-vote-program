const app = getApp()
Page({
  data:{		//此处定义本页面中的全局变量	
    result:'',
    username: '',
    userphone: '',
    userID:'',
    userinf:'',
    userroom:'',
    userpaw:''
  },
  inputName: function(e){	// 用于获取输入的账号
    this.setData({
      username: e.detail.value	//将获取到的账号赋值给username变量
    })
  },
  inputPhone: function(e){	// 用于获取输入的账号
    this.setData({
      userphone: e.detail.value	//将获取到的账号赋值给username变量
    })
  },
  inputID:function(e){
    this.setData({
      userID:e.detail.value
    })
  },
  inputInf:function(e){
    this.setData({
      userinf:e.detail.value
    })
  },
  inputroom:function(e){
    this.setData({
      userroom:e.detail.value
    })
  },
  inputPwd: function (e) {		// 用于获取输入的密码
    this.setData({
      userpwd: e.detail.value	//将获取到的账号赋值给passwd变量
    })
  },

  save: function(e){		//与服务器进行交互
  if(this.data.username == ''){
    wx.showToast({
      title: '请填写名字！',
    })
    return;
  }
  else if(this.data.userphone == ''){
    wx.showToast({
      title: '请填写手机号！',
    })
    return;
  }
  else if(this.data.userID == ''){
    wx.showToast({
      title: '请填写身份证号！',
    })
    return;
  }
  else if(this.data.userinf == ''){
    wx.showToast({
      title: '请填写房产证号！',
    })
    return;
  }
  else if(this.data.userroom == ''){
      wx.showToast({
        title: '请填写住址！',
      })
      return;
    }
  else if(this.data.userpwd == undefined){
    wx.showToast({
    title: '请填写密码！',
  })
  return;
  }
    wx.request({
      url: 'https://syu.fit/api/info/',	//获取服务器地址，此处为本地地址
      header:{
        "content-type": "application/x-www-form-urlencoded"		//使用POST方法要带上这个header
      },
      method: "POST",
      data: {		//向服务器发送的信息
        username: this.data.username,
        userphone: this.data.userphone,
        userID:this.data.userID,
        userinf:this.data.userinf,
        userroom:this.data.userroom,
        userpwd:this.data.userpwd
      },
      success: res => {
        if (res.statusCode == 200) {
          wx.reLaunch({
            url: '../index/index',
          })
          wx.showToast({
            title: '消息待审核！',
          })
        }
      }
    })
}
})
