// pages/log/mesDetail/mesDetail.js
var app = getApp();
app.globalData.userID
Page({

  /**
   * 页面的初始数据
   */
  data: {
    data:[],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var mesID = options.mesID
    wx.request({
      url: 'https://syu.fit/api/getperson/' + mesID +"/",
      /*header:{
        "content-type": "application/x-www-form-urlencoded"		//使用POST方法要带上这个header
      },*/
      method:'GET',
      dataType:'json',
      responseType:'text',
      data: {		//向服务器发送的信息
        userID:app.globalData.userID,
      },
      success:(res)=>{
        this.setData({
          data: res.data,
          photo:res.data.photo.split(","),
        })
      },
    })
  },
  del:function()
  {
    var that = this
    wx.request({  //再次请求投票任务的详情数据，防止其他用户更新了数据库
      url: 'https://syu.fit/api/delmes/',
      header:{
        "content-type": "application/x-www-form-urlencoded"		//使用POST方法要带上这个
      },
      method: "POST",
      data: {
        id: that.data.data.id,
        userID : app.globalData.userID,
      },
      dataType: 'json',
      success: function (res) {
        that.setData({
          result: res.data	//服务器返回的结果
        })
        if(res.data.status = true)
          {
            wx.showToast({
              title: '删除成功',
            })
            wx.reLaunch({
              url: '../log',
            })
          }
      }
    });
  },
  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})