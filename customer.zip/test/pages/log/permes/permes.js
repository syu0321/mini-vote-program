// pages/log/permes/permes.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    permes:[],
    inputText : '',
    name: '',
    phone: ''
  },
  inputText: function(e){	// 用于获取输入的账号
    this.setData({
      inputText: e.detail.value	//将获取到的账号赋值给username变量
    })
  },
  name:function(e){
    this.setData({
      name:e.detail.value
    })
  },
  phone:function(e){
    this.setData({
      phone:e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var id = options.id
    wx.request({
      url: 'https://syu.fit/api/permes/'+ id +"/",
      method:'GET',
      dataType:'json',
      responseType:'text',
      success:(res)=>{
        this.setData({
          permes: res.data,
          photo:res.data.photo.split(","),
        })
      },
    })
  },
  ok:function(){
    var that = this
    if(that.data.inputText == ''){
      wx.showToast({
        title: '请输入回复内容！',
      })
      return;
    }
    else if(that.data.name == '')
    {
      wx.showToast({
        title: '请输入姓名！',
      })
    }
    else if (that.data.phone == '')
    {
      wx.showToast({
        title: '请输入手机号！',
      })
    }
    else
    {
      wx.request({
        url: 'https://syu.fit/api/returnmes/',	//获取服务器地址，此处为本地地址
        header:{
          "content-type": "application/x-www-form-urlencoded"		//使用POST方法要带上这个header
        },
        method: "POST",
        data: {		//向服务器发送的信息
          id:that.data.permes.id,
          name:that.data.name,
          phone:that.data.phone,
          person: that.data.inputText
        },
        success: res => {
          if(res.data.status = true)
              {
                wx.showToast({
                  title: '提交成功',
                })
                wx.navigateBack({

                  url: '../tolmes/tolmes',
                })
              }
        }
      })
  }
  },
  photo_view: function(e){
    var that = this
    var url = e.currentTarget.dataset.url;
    wx.previewImage({
     current: url, // 当前显示图片的http链接
     //urls: that.data.previewImgArr.split(",") // 需要预览的图片http链接列表
     urls:that.data.photo
   })
   },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
   
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})