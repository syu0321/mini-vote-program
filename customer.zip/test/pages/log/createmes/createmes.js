// pages/log/createmes/createmes.js
var uploadImage = require('../../js/uploadImg/uploadImg.js');
var app = getApp();
app.globalData.userID
var utils = (function () {
  var time = new Date()
  return {
    year: time.getFullYear(),
    month: time.getMonth() + 1,
    date: time.getDate(),
    hours: time.getHours(),
    minutes: time.getMinutes()
  }
})()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    title:'',
    inputText : '',
    imageList:[],
    photo:[],

  },
  onLoad: function (options) {
  },
  title: function (e) {
    var that = this;
    that.setData({
      title: e.detail.value,
    });
  },
  inputText: function(e){	// 用于获取输入的账号
    this.setData({
      inputText: e.detail.value	//将获取到的账号赋值给username变量
    })
  },
  choose: function () {
    var that = this
    wx.chooseImage({
      count: 9, // 默认最多一次选择9张图
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        that.setData({
          imageList:that.data.imageList.concat(res.tempFilePaths)
        })
        for (var i = 0; i < that.data.imageList.length; i++) {
          //显示消息提示框
          wx.showLoading({
            title: '上传中' + (i + 1) + '/' + that.data.imageList.length,
            mask: true
          })
          //上传图片
          //你的域名下的/images/当前年月日文件下的/图片.png
          //图片路径可自行修改【(这二个参数就是你oss地址目录的下一个路径目录，比如:https://xxx.com/images/xxx.png)】
    
          uploadImage(that.data.imageList[i],'message/',
            function (result) {
              console.log("======上传成功图片地址为：", result);
              photo:that.data.photo.push(result)
              //这个result就是返给你上传到oss上的地址链接
              wx.hideLoading();
              wx.showToast({
                title:'上传成功'
              })
            }, function (result) {
              console.log("======上传失败======", result);
              wx.hideLoading()
              wx.showToast({
                title:'上传失败'
              })
            }
          )
        }
      }
    })
  },
  deleteImg: function (e) {
    var that = this;
    var imgs = that.data.imageList;
    var index = e.currentTarget.dataset.index;
    imgs.splice(index, 1);
    that.data.photo.splice(index, 1);
     this.setData({
       imageList:imgs,
       photo: that.data.photo
     });
  },
ok:function()
{
  var myDate = new Date();
  var time = myDate.toLocaleDateString();
  if(this.data.title=='')
  {
    wx.showToast({
      title: '请填写主题！',
    })
    return;
  }
  else if(this.data.inputText == ''){
    wx.showToast({
      title: '请填写投诉内容！',
    })
    return;
  }
    wx.request({
      url: 'https://syu.fit/api/creatmes/',	//获取服务器地址，此处为本地地址
      header:{
        "content-type": "application/x-www-form-urlencoded"		//使用POST方法要带上这个header
      },
      method: "POST",
      data: {		//向服务器发送的信息
        userID:app.globalData.userID,
        date : time,
        title:this.data.title,
        message: this.data.inputText,
        photo:this.data.photo,
      },
      success: res => {
        if(res.data.status = true)
            {
              wx.showToast({
                title: '提交成功',
              })
              wx.switchTab({
                url: '../../log/log',
              })
            }
      }
    })
},
  /**
   * 生命周期函数--监听页面加载
   */


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})