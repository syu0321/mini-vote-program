var fileHost="https://vote-mini.oss-cn-zhangjiakou.aliyuncs.com/"
var config = {
  //aliyun OSS config
  uploadImageUrl: `${fileHost}`, //默认存在根目录，可根据需求改
  AccessKeySecret: 'Zlhl2UyJlu0rGT6T0ab9PyUplZIksy',
  OSSAccessKeyId: 'LTAI5tCutKNdCRU4yvKT6SKz',
  timeout: 87600 //这个是上传文件时Policy的失效时间
};
module.exports = config
