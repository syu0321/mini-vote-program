
App({
  globalData:{
    //appid: 'wx755d020093d61f8c',//appid需自己提供，此处的appid我随机编写  
    //secret: '08b71a2ec1da8f9b08836bb48c4042e2',//secret需自己提供，此处的secret我随机编写 
    //openid:'', //自定义
  },
  onLaunch:function()
  {}
})
